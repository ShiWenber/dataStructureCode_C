package ynu.ls.coloring;



public class SimaColoring {

	
	
}
